# Paste into Codex or Claude Code: local discovery

Use the adjacent Agency Control handoff as a proposal. Inspect my actual DBVC checkout and current working tree before implementation. Read its AGENTS.md, docs/README.md and docs/agent-entrypoints.md, then the narrow capability facets for hooks, identity, Bricks, proposals and CLI. Do not load the entire docs library by default.

Our agreed architecture is a separate agency hub plus an optional DBVC connection module. DBVC owns local execution; Visual Editor remains optional. We need individual framework-object subscriptions plus client-specific staging/production comparisons. Begin with observation only.

The remote baseline reviewed was franklyco/db-version-control-main at 977888535a306989e48c5a34104fb9d101298cf3. Its commit excludes some local Bricks work. Preserve my uncommitted changes, identify relevant differences, and choose an implementation base using local evidence. Do not reset, clean, automatically stash, switch to an older branch, or copy engines to a second repository.

Run/read scripts/inspect_dbvc.py from the handoff. Confirm the active LocalWP plugin path if a test site is available. Map exact methods, signatures, hook arguments/timing, current consumers, settings gates, schema versions, test fixtures, job/backup services and capability records. In particular check export-gated dbvc_after_option_update, order-sensitive canonicalization, protected variants, journal completion, UID fallback and older ID-based apply.

Produce a short reconciliation report in the approved working docs location, a reuse/adapt/new/defer table, and the minimal files for M1/M2. Confirm two comparison baselines, hub-owned recipient routing and environment clone/epoch handling. Capture sanitized representative Bricks class/variable and service fixtures. Finish the M0 contract/fixture scaffold and record unresolved prerequisites. Do not apply client content or deploy. If paths cannot be found in the supplied workspace, ask for the specific missing local checkout path after completing available discovery.
