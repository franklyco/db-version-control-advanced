# Paste after M0: implement the observation pilot

Read START-HERE.md, the local M0 reconciliation, docs/03 through docs/05, and existing repo instructions. Implement one bounded slice at a time toward M1/M2. Use the selected local base; do not assume the remote review SHA is current.

Build a separate Agency Control hub and optional DBVC connection module. Scope: individual Bricks global classes, individual global variables and service CPT posts. Detect persisted changes independently of Visual Editor and automatic export. Mark dirty/coalesce/reread; no remote calls during saves. Identity assignment is an explicit enrollment writer, not part of an inventory read.

Use durable local outbox/hub event receipts, authenticated environment membership, explicit subscriptions, typed/versioned observation events, bounded inbox/cursors, deduplication and reconciliation for missing hooks/sequence gaps. Offline subscribed staging receives backlog after reconnect; revoked/disabled subscriptions do not receive new work. Hub derives routes. Never accept sender-defined client membership or recipients.

Create the exact two-client disposable lab from docs/08. A production managed-class change reaches the framework review queue and only A's subscribed staging. A service change reaches only A's staging, without framework promotion. B is an isolation control. Test duplicate/reused-ID-different-body, stale/out-of-order/gap, offline recovery, export-disabled capture, ordered data and untracked class neighbors. Reporter state writes are allowed in the disposable lab; client content application is not in this phase.

Keep Bricks/manual/Visual Editor functionality compatible. Add only needed narrow services/hooks/commands. Map public surfaces to DBVC capability records and follow agent-docs maintenance. Record actual tests and runtime evidence; distinguish source checks from live proof. Finish the selected slice with evidence and next task rather than broadening into remote apply, AI decisions or template dependency coverage.
