# Paste after M1–M3 evidence: prepare and guarded round trip

Read the reconciled contracts and docs/06–08. Confirm observation, client isolation and baseline/override behavior are proven before enabling any content writer. This prompt describes the next task; use it only for the explicitly designated disposable local/staging lab, not production.

First implement prepare-only operations. Resolve existing DBVC UIDs, individual Bricks object mappings and known dependencies. Preserve unrelated entries in shared Bricks options. Produce immutable target-specific plans, current storage fingerprints, profile versions and blockers. Do not expose the older numeric-ID apply path directly and do not bypass proposal/portability safety checks.

Then prove one reviewed round trip using a page/service, supported ACF text/image, one Bricks template and one global variable. Use different numeric IDs. Include production-only edit preservation, conflicting edit rejection, a late external edit, lost response, idempotent retry and a bounded failure/recovery drill. Establish the actual concurrency strategy for writers outside DBVC; a DBVC-only lock plus update_option is not sufficient.

Adapt existing import/portability/backup services. Validate unsupported domain/reference cases as blockers. Keep before images and operation journals; check compensation results. Verify canonical stored data, asset references and Bricks rendering/cache regeneration separately. Later edits must block destructive rollback. No fleet apply until this exact target boundary has evidence.

Update the relevant capability/docs records once per coherent tested boundary. Do not call this globally live-verified from a narrow fixture. End with the precise supported domains and remaining gaps, plus a canary rollout proposal.
