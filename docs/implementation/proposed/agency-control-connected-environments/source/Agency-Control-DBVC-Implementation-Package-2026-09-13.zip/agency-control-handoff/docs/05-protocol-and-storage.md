# Draft protocol and persistence

Status: draft v0.1 design. Only the observation event schema is machine-readable in this package. The API below is a proposed contract, not current DBVC routes. Finalize names and compatibility behavior after local discovery. Freeze one small versioned contract before networking.

## Capability negotiation

Enrollment returns protocol version, environment identity/epoch, verified client membership, supported domain/canonicalizer versions and permitted operations. Advertise inventory/report independently of prepare/apply. Include DBVC, adapter, Bricks and relevant ACF/schema versions in diagnostic compatibility metadata. Unknown mandatory capabilities block that operation while leaving compatible reporting available.

## Proposed hub routes under `agency-control/v1`

| Operation | Side effect / boundary |
|---|---|
| POST enrollment exchange | Single-use expiring enrollment token consumed; environment-scoped credential created |
| POST event batches | Hub-owned event/receipt writes; no client content writes |
| GET inbox after cursor | Read bounded items scoped to authenticated environment; no content application |
| POST delivery acknowledgements | Advance only that environment's delivery state |
| GET framework version manifest | Scoped authorized read of immutable version |
| POST operation results | Store target-bound prepare/apply/verify/recovery receipts; later milestone |

For asynchronous execution, a target pulls a typed operation. No arbitrary PHP, SQL, HTTP URL or WP-CLI command execution. Separate reporting permission from release execution, definition publication, enrollment and client detail access. Destination revalidates a release against its capabilities and policy; the hub is a coordinator, not blanket authority.

## Authentication and transport

Use HTTPS with certificate validation and revocable environment credentials. WordPress Application Passwords can supply transport authentication, but endpoints must bind that principal to the exact enrolled environment/client and permitted actions. Do not use one administrator credential across the fleet. Inventory schemas and per-domain capabilities are enforced server-side.

Do not blindly reuse the legacy HMAC format for a broader protocol. Review whether signatures bind method, route, body hash, target, operation, issued/expiry times and nonce. Validate signature before recording replay state; validate command type and target independently. Credential scope/key rotation are explicit. Clock skew matters for expiry, not for determining who edited an object last.

Enrollment is initiated from the relevant local/site admin with explicit client selection. Short-lived tokens do not carry reusable credentials in URLs/logs. Revocation disables future report/intake/execution and pending operations; retention and cleanup are separate decisions.

An authenticated source does not grant permission to fetch arbitrary media/package URLs. For later asset transfers use authenticated permitted origins/paths, size and checksum limits, bounded redirects, archive path traversal checks and file validation. An unrecognized private-network target is not silently made reachable. Protected uploads require the protocol's scoped transfer, not public URLs.

Official transport baseline: [WordPress REST authentication](https://developer.wordpress.org/rest-api/using-the-rest-api/authentication/).

## Persistence boundaries

Use dedicated indexed tables for growing queues/events/receipts, not ever-growing serialized option arrays. Reuse DBVC database migration/job helpers where they fit; add new ownership records in its capability manifest. Do not repurpose the Visual Editor journal tables as the general network queue.

| Stage | Local site data | Hub data |
|---|---|---|
| Observation pilot | Enrollment reference, dirty objects, scoped identities, current snapshots, durable outbox/cursor | Clients/environments, subscriptions, event deduplication, delivery cursors, current projections |
| Comparison | Pair/object/profile baselines, local override binding | Framework definition versions, subscription/override policy, scoped comparison projections |
| Releases | Prepared operations, intended patches, before images, write journal, receipts | Immutable release manifests, approval records, rollout targets and outcomes |

Logical models may share tables where indexing/retention is coherent; do not create every future table in M0. At minimum enforce uniqueness for enrolled identities, event ID within agency/environment/epoch, event sequence within epoch, subscription identity and operation ID/payload binding.

Deduplication lookup and record insertion must be atomic under simultaneous requests. Two workers must not both apply the same operation. Bind each idempotency key to a canonical request digest plus target; same key/different body is a conflict. Expiring a short response cache does not permit replay of an old applied operation. Durable receipts/tombstones must outlive the valid command/retry window.

Store observed_at (sender) and received_at (hub), monotonic sequence, installation epoch, schema/profile versions and reconciliation status. Never let arrival time or sender clock overwrite a later known sequence. Retention can compact raw observations while keeping current state, baselines, override intent and operation receipts. Baseline and recovery data may not be pruned merely because a notification was read.

Metadata-only events still reveal object identities and changes. Keep them scoped and retain only needed fields. Fetch rich diffs on demand with the appropriate client permission. Schema omits arbitrary payloads, secrets, raw field values and recipient lists intentionally.

For a LocalWP source, “fetch on demand” means enqueue a scoped snapshot request for that source to pull and upload through its outbound connection. It does not mean the hub can call its `.local` URL. Retain enough local observation history to answer the requested revision; if it was pruned or the source is offline, show detail unavailable/pending and do not substitute a newer snapshot without labeling it. Later approved releases upload immutable bounded payloads/assets so targets can complete a prepared deployment without depending on the author's laptop remaining online.

## Draft operation lifecycle

`offered → received → preparing → prepared|blocked → approved → applying → applied → verifying → verified`.

Failures can produce `failed`, `recovery_required`, `compensating`, `compensated`, `recovery_failed`, `cancelled` or `expired`. These are separate persisted outcomes; receipt and UI must not compress them into “synced.” Approval is bound to immutable content + target + expected state + policy/dependency versions, and becomes stale if those change.

The offline demo in this package implements only comparison and routing examples. It does not implement this network lifecycle.
