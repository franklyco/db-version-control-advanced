# Capture, routing and offline behavior

## Start with two managed domains and one client domain

The first connected pilot observes individual entries in `bricks_global_classes`, individual entries in `bricks_global_variables`, and `service` posts. Capture the real persisted shape on the actual Bricks version. Templates/media come after basic routing and order-sensitive normalization tests. ACF content storage depends on field type and registration, so discover the exact fields used by the pilot.

## Capture process

1. Allowlisted lifecycle hooks mark an object/domain dirty in local DBVC-owned storage. No network work on the editor's save request.
2. Coalesce related post/meta/option signals and reread settled persisted state in a bounded worker. Include source revision/generation; a stale worker result cannot overwrite a newer observation.
3. Compare with last observed canonical snapshot; emit only a semantic change. Record actor/source context only when known. Reconciliation scans often cannot identify the editor.
4. Persist the event in a durable local outbox before sending it. A crash between the original WordPress write and outbox insertion is possible; periodic reconciliation repairs that gap. Do not claim transactional capture of arbitrary WordPress writes.
5. Send bounded batches. The hub authenticates enrollment, validates schema, deduplicates, stores receipt and routes using its registry. Retry transient failures with backoff and jitter.
6. Poll recipient inboxes while sites run. Maintain per-environment durable cursors; delivery acknowledgement is distinct from viewing, preparing or applying.

Candidates: WordPress `wp_after_insert_post`, added/updated/deleted post meta, option creation/update/deletion, successful post deletion, taxonomy changes where relevant. Validate exact hooks/signatures on the local version. `wp_after_insert_post` supplies a post-save boundary for the core operation, but integrations may write more data later; settled rereads and reconciliation remain necessary. Existing DBVC hooks provide useful context but cannot be the sole capture path where export gates suppress them.

Official hook references: [wp_after_insert_post](https://developer.wordpress.org/reference/hooks/wp_after_insert_post/), [updated_option](https://developer.wordpress.org/reference/hooks/updated_option/).

For options use explicit allowlists; never export every option to the hub. Updating a single class may rewrite an entire Bricks option. Adapter comparison must split that into individual managed-object differences and preserve untracked entries. Check related category options as dependencies when a selected change needs them.

## Routing rule table

| Originating change | Fleet framework review | Same-client subscribed environments | Other clients |
|---|---|---|---|
| Edit a subscribed framework class/variable on production | Yes, scoped to that definition/subscription | Yes, production excluded as sender | No incoming change |
| Edit client-only class/variable | No framework item | Yes | No |
| Edit service post | No framework item; optional client activity summary | Yes | No |
| Studio publishes approved framework release | Release/adoption view | Only eligible targeted subscribers per policy | Only their explicitly targeted instances |
| Apply/rollback produces a local observation | Receipt + actual resulting state | Update appropriate comparison | Never reinterpret as a new framework proposal automatically |

Routing comes from the authenticated registry/subscription, not an untrusted `audience` field in the event. The sender cannot choose another client_id or define recipients. Framework changes on client A do not become change deliveries to client B merely because both subscribe to that framework definition.

“Active staging” means enabled subscription, not currently online. An offline enrolled staging site retains pending notifications and receives them after reconnect. Disabled/revoked subscriptions receive no new deliveries; reconnection may require an authorized snapshot if retention expired. Do not silently drop messages because a laptop was asleep.

## Noise and loop controls

Carry event_id, environment epoch and sequence, root cause/operation ID and origin kind (`human`, `apply`, `rollback`, `reconciliation`). Exact duplicate deliveries are harmless; reused event IDs with different content are rejected. Older events are historical, not current state. Gaps trigger resynchronization and an incomplete flag.

Imported changes still need observation and verification. Suppress automatic redistribution of the same causal operation, not all event capture during imports. Otherwise side effects and partial failures disappear. A receipt whose actual hash differs from the intended target must show failure/divergence.

Batch/group related changes into one operator task. Avoid a notification per meta write. Allow count-only fleet summaries while client detail requires the appropriate permission. Retention limits must cause a visible snapshot-required state, not false synchronization.

## Scheduling

Provide an explicit worker invocation for local CLI and system cron once implemented. WP-Cron can be a fallback; it is traffic-driven. LocalWP must be running. Do not add network calls to ordinary page loads to create the illusion of real-time delivery. Candidate initial polling interval: 60 seconds while an active worker runs, configurable and measured; this is a proposal, not existing DBVC behavior.

See [WordPress scheduling](https://developer.wordpress.org/plugins/cron/) and [system scheduler integration](https://developer.wordpress.org/plugins/cron/hooking-wp-cron-into-the-system-task-scheduler/).
