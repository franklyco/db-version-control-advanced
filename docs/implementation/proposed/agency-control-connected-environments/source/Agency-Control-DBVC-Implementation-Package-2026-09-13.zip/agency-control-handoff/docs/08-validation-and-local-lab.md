# Validation and local lab

## Setup

Use disposable instances with recognizable environment names. Record actual plugin checkout path in each instance, git HEAD, dirty file summary, WordPress/PHP/DB versions, Bricks version, ACF provider/version and adapter gates. LocalWP installations can accidentally load a different copied plugin than the agent edits; runtime provenance is required before claiming success.

Fixture IDs and hashes are collected after creation, never guessed. Different client sites must use separate client identities even when built from the same blueprint. Deliberately make numeric post/template/attachment IDs differ across the two environments used for M5.

## Meaningful case matrix

| Group | Cases | Proof |
|---|---|---|
| Capture | Standard post edit, Bricks class save, variable save, ACF field save, WP-CLI edit, meta add/update/delete, option create/delete, export gate disabled | Persisted state changes yield correct scoped dirty objects and one settled report |
| Reconciliation | Simulated lost hook/outbox gap, worker restart, stale worker generation, direct DB change in disposable fixture | Snapshot reconciliation repairs missed observations; state flagged incomplete until repaired |
| Normalization | Map key reorder, ordered list reorder, meaningful `time` field, null vs missing, ID/URL localization | No false clean state or noise; canonical profile recorded |
| Identity | Existing UID, unmatched UID, conflicting registry/meta binding, clone epoch, title rename | No numeric fallback for unmatched UID; no accidental enrollment reuse |
| Routing | A class → hub + A staging; A service → A staging only; B control; disabled vs offline subscription | No cross-client deliveries or framework promotion |
| Transport | Duplicate, reused ID/different body, sequence gap, old delivery, timeout, revoked credential, wrong client claim | Durable scoped receipt, no duplicate state transition, no authority from sender claims |
| Comparison | Source-only, target-only, converged, conflict, unknown baseline, incomplete coverage, profile mismatch | Expected three-way state and separate framework status |
| Overrides | Approved value, later local change, newer framework version, detach | Expected variation preserved and fresh drift visible |
| Prepare | Required dependency absent, unsupported shape, stale destination, unrelated class neighbors | Exact patch or explicit blocker; no content change |
| Apply | Lost response, same operation retried, simultaneous workers, external editor race | Once-effective application under proven strategy or explicit block |
| Recovery | Failure after media/create/template/option boundaries, rollback after later edit, reused assets | Verified compensation or recovery-required; no unrelated deletion |
| Rendering | Builder opens, expected frontend/media/styles present, cache/CSS rebuild after apply and restore | Data and rendering results recorded separately |

## Existing tests worth locating

`tests/phpunit/BricksAddonIdempotencyTest.php`, `BricksAddonPackagesTest.php`, `BricksAddonPhase19ATest.php`, `BricksAddonPhase19BTest.php`, `BricksAddonPhase19CTest.php`, `BricksAddonPhase19DTest.php`, `BricksPortabilityManagerTest.php`, `BricksCliTest.php`, `BricksReferenceMappingTest.php`, and `CoreImportUidPreservationTest.php`. Confirm exact test names and dependencies locally. A historical tracker pass is an evidence lead, not this run's result.

`scripts/check-bricks-phase19-evidence.php` and the existing runtime smoke scripts are inspection leads. Read their source/arguments and target assumptions before running: some runtime scripts may create or mutate fixtures. Do not invoke all scripts to obtain a larger green count.

## Minimum evidence record

Record claim, source commit and dirty digest, active runtime path, fixture scope, commands/inputs, expected and observed state, before/after authoritative content fingerprints, response/receipt IDs, cleanup and untested boundaries. Reporting tests compare content/Bricks options independently from allowed reporter storage writes.

Source checks cannot prove live registration; live registration cannot prove apply; a successful HTTP response cannot prove stored content; data checks cannot prove rendering. Mark `blocked`, `partial` and `not_run` honestly.

## Existing gates

Run relevant syntax checks, selected affected test groups, necessary frontend build, the affected regression suite once at slice close, and DBVC's agent-docs maintenance when public surfaces change. Resolve unrelated baseline failures by documenting them; do not silently weaken tests or spend the entire slice fixing unrelated modules.

Local command examples after prerequisites are verified:

```bash
composer test:smoke
vendor/bin/phpunit --filter 'BricksAddonPackagesTest|BricksAddonIdempotencyTest|BricksPortabilityManagerTest|CoreImportUidPreservationTest'
composer agent-docs:check
git diff --check
```

Use narrower filters when they resolve the slice's risk. The broad example is for a release boundary touching those owners, not every edit.

## Package-only validation

The supplied Python executable specification tests synthetic routing, identity scoping, override classification, event replay and basic three-way states. It is intentionally not production engine code. Its results must not be copied into DBVC capability records as live/runtime evidence. PHP lint and WordPress activation of the admin shell remain local prerequisites where PHP is unavailable in the producing environment.
