# Delivery plan

All milestones below are proposed and NOT STARTED in DBVC. The package supplies planning assets and an offline specification only. Effort ceilings are suggested engineering timeboxes, not quotes or delivery promises; agent time does not remove WordPress/runtime QA.

| Milestone | Working result | Required evidence / exit | Suggested timebox |
|---|---|---|---|
| M0: reconcile and contract | Known local base, reuse map, domain fixtures, final first event contract | Actual source/dirty state + installed runtime identified; capability gaps recorded; no hidden rewrites | 1–2 engineering days |
| M1: local observation | Optional DBVC reporter captures class, variable and service changes into local storage | Save via Bricks/editor/CLI, no-op, ordering, export disabled and reconciliation cases; zero content writes by scans | 2–4 days |
| M2: connected reporting pilot | Hub receives, scopes and displays events from two client ecosystems | Authentication, isolation, deduplication, gap/offline/reconnect cases and known drift visible; zero content application | 3–5 days |
| M3: comparison and decisions | Shared baselines, framework subscriptions, approved overrides and clear queues | Three-way comparisons, independently edited prod/staging, profile mismatch and stale observations | 3–5 days |
| M4: prepare only | Destination returns exact proposed patch and dependency/identity blockers | UID mismatch, selected class vs untracked neighbors, stale target and dependency gaps; no content apply | 3–5 days |
| M5: one reviewed round trip | One bounded release applied/verified/restored on disposable sites | Different IDs, retry/lost response, concurrent edit handling, media/reference checks, restored before state | 5–10 days, highest uncertainty |
| M6: controlled fleet rollout | Immutable framework version moves through canary then cohorts | Per-target receipts, overrides preserved, failure pauses later targets, offline receipt handling, permission checks | Re-estimate after M5 |

If a timebox is exceeded because an existing primitive fails a core assumption, stop adding features and produce a specific repair decision. Never label a milestone complete because all classes were scaffolded.

## First pilot scope

One studio hub; client A production and staging; client B production and staging as isolation controls. All can initially be disposable LocalWP instances. Enroll with fictional client data and explicitly shared definitions. Later move only the hub and one disposable target to hosted staging to prove the actual network topology.

Managed objects: one Bricks class and one variable shared by A and B via separate subscriptions. Client content: one service post per client with a stable UID. Local observations and hub state may be written; client content must remain unchanged by reporting workers.

The decisive scene: edit A production's class and service post, then watch the hub show a framework exception for the class and only A staging receive both notifications. B remains unchanged. Stop A staging, repeat, restart it and reconcile. Re-deliver the event and show one logical notification.

## Early decisions already recommended

- Separate hub product/repo; DBVC remains the site engine.
- Hub-mediated outbound transport in the agency pilot.
- Observation first; automatic content application disabled.
- Individual object subscriptions; no blanket fleet ownership of every Bricks object.
- Two baselines; framework release version and environment agreement are distinct.
- Whole-object review for complex repeaters/Bricks trees initially.
- Supported capabilities advertised per domain; no universal apply promise.
- Existing Visual Editor and manual workflows remain operational.

## Decisions for M0 evidence

Select the actual local base; confirm plugin/PHP/Bricks/ACF versions; capture real class/variable shapes; identify supported addon loader; evaluate exact identity and recovery services; record hub runtime/DB constraints and test commands. If one framework-definition location is needed, choose a studio-owned canonical source environment and publish immutable versions through the hub. The hub catalog must not implicitly mean editing raw Bricks data on the hub.

## Deliberately later

Automatic conflict merging, live save-to-prod mirroring, multi-hub federation, customer-facing portal, AI auto-approval, universal third-party storage adapters, a whole-site database clone system, mobile app, billing, marketplace, and a full Visual Editor extraction. Revisit only after the complete two-client scene works.

## Small PR sequence

M0 docs/fixtures → M1 canonical snapshots → M1 capture/outbox → M2 hub enrollment and ingestion → M2 inbox/projection/UI → M3 baselines/overrides → M4 destination preparation → M5 guarded writes/recovery. Keep unrelated Visual Editor work outside these diffs. One tested domain owner change per PR where practical. Hub/DBVC compatibility must tolerate reporting upgrades before the matching apply handler ships.
