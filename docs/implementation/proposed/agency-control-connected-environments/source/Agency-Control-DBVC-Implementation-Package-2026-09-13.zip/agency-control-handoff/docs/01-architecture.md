# Architecture and repository boundary

Status: proposed. Repo-backed facts are in the evidence map; names under Agency Control are new design terms.

## Product promise

An agency operator can see where shared framework items differ, understand each client's environment changes, and prepare a bounded release with known consequences. Reporting works independently of Visual Editor and independently of automatic export settings.

## Responsibilities

| Owner | Responsibility | Explicit boundary |
|---|---|---|
| Agency hub | Client/environment registry, ownership, subscriptions, framework catalog, event intake, projection, review and rollout coordination | No direct SQL into remote sites; no duplicated Bricks importer |
| DBVC connection module | Enrollment, capabilities, capture, local outbox, outbound transport, inbox, operation receipts | No fleet policy authoring; deny unsupported operations |
| DBVC engines/adapters | Identity resolution, extraction, comparison, destination prepare/apply/verify/recovery | Local authority validates every write |
| Bricks adapter | Individual classes, variables, templates and references using verified storage shapes | Bricks owns storage; adapter owns interpretation and supported mutation |
| Visual Editor | Editing UI and contextual journal enrichment | Optional; its journal is not the sole source of changes |
| Manual DBVC tools | Inspection, authoring, granular transfer and recovery | Continue through existing supported services |

Two separate Git repositories: the existing DBVC repository and a new `agency-control-hub` repository. Keep draft wire contracts in the hub repo initially, versioned as a small released bundle; DBVC consumes pinned schema/fixtures. Add a standalone contracts repo only when independent consumers/release cadence justify it. Never copy PHP import engines between repositories.

Suggested DBVC layout after local discovery: `includes/Dbvc/Connected/` for runtime services, `addons/connected-environments/bootstrap.php` for the optional gate, and a dedicated CLI file only when the first real command exists. These are proposed paths. Confirm the local addon registration convention before wiring them into bootstrap.

The hub shell in this package is deliberately small. Its eventual module boundaries are Registry, FrameworkCatalog, Events, Routing, Projections, Reviews, Releases, Transport and Admin. Create classes when a vertical slice needs them; do not fill the tree with unused abstractions.

## Hub topology

Start with a dedicated studio WordPress installation. Both client production and staging initiate outbound connections to it. LocalWP receives work through polling while running. A public deployment of the studio hub is needed for a hosted site's outbound connection in the real pilot; an all-LocalWP lab can use mutually resolvable local addresses. A LocalWP hub is not automatically reachable from a production server.

The earlier direct staging/production pair design remains conceptually compatible. For the agency pilot choose **hub-mediated routing only** to avoid competing routes, credentials and baselines. Do not implement direct peer mode and hub mode simultaneously. The wire model separates logical source/destination from the endpoint carrying the message.

For a client-only change, the hub can hold a minimal scoped event and deliver it solely to subscribed environments of that client. This is a transport function; it does not promote the content into the framework catalog or make it visible to unrelated clients. Rich client payload relay requires its own permitted scope and retention policy.

## Contracts before extraction

Use narrow application services around existing functionality. An adapter capability distinguishes inventory, snapshot, dependencies, prepare, apply, verify and compensate. Supporting inventory does not imply support for apply. The hub never assumes a method exists because it found a class name in a source tree.

Extract existing transport primitives only when shared-rules behavior can remain compatible under tests. Legacy mothership/client roles stay intact for existing users. New environment roles (`local_staging`, `server_staging`, `production`) and protocol identities must not overload those old role values.

## Technology choices

Initial runtime stays PHP + WordPress APIs + MySQL/MariaDB on the existing supported stack. Reuse DBVC's test tooling and existing WordPress admin component practices. Use semantic CSS classes and centrally scoped custom properties for new hub UI, matching Rhett's preference. No new frontend framework or external queue service is needed for the first reporting screen. Do not introduce a PHP minimum until the local plugin/runtime constraints are confirmed; the shell uses conservative syntax.

No AI model is needed for ownership, routing, hash comparison or apply decisions. Optional future AI can explain diffs or draft a release summary from permitted evidence; it cannot invent dependency coverage or approve its own writes.
