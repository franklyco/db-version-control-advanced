# Local agent workflow

## Session order

1. Read existing DBVC `AGENTS.md`, `docs/README.md`, `docs/agent-entrypoints.md`, then the narrow relevant facet. This package does not replace local instructions.
2. Confirm the chosen working directory and read `git status --short` before edits. Preserve uncommitted work; do not stash/reset/clean automatically.
3. Follow `prompts/01-local-discovery.md`. Select one owning repository for each change. If a clean worktree is useful, base it on a verified local ref and explicitly handle relevant dirty changes; a worktree does not include them automatically.
4. Implement one bounded milestone slice, retaining backwards compatibility through existing entrypoints.
5. Record evidence and update the relevant capability before changing unrelated boundaries.
6. Leave a compact session handoff with completed slice, exact files, tests, remaining blockers and next concrete task.

No agent swarms or parallel editing are required. Codex/GPT/Claude Code can work sequentially from the same handoff. If multiple agents are explicitly chosen later, assign separate file ownership and one integration owner; never let them implement separate versions of the same transport contract.

## Verified tooling from the reviewed checkout

| Command | Purpose / caution |
|---|---|
| `composer agent-docs:query -- <tags>` | Narrow capability discovery |
| `composer agent-docs:discover` | Regenerates discovery data; review output |
| `composer agent-docs:refresh` | Rebuilds discovery/indexes; generated-file writes |
| `composer agent-docs:check` | Strict contract/docs check |
| `composer test:smoke` | Bootstrap smoke suite |
| `composer test` | Full DBVC PHPUnit suite; use at an appropriate affected release gate |
| `npm run build` | Existing WordPress admin build entries; needed only for affected frontend changes |
| `wp dbvc capabilities list --safety=read_only` | Discover scoped read-only capabilities on actual site |
| `wp dbvc capabilities show addon.bricks.drift --format=json` | Inspect reviewed capability metadata |
| `wp dbvc capabilities doctor` | Verify packaged catalog/registration; no dispatch of its listed writers |
| `wp dbvc bricks doctor --format=json` | Bricks runtime/schema diagnosis |

Do not invent `wp dbvc connected ...` as an existing command. Add CLI parity only for operations the pilot actually needs, then update the command index via the existing maintenance flow.

## Documentation placement

The hub repo owns the platform architecture and wire contract. DBVC owns local adapter/execution/capability docs. Propose one DBVC implementation doc under the locally appropriate active/proposed location; update `docs/roadmap.md`. Canonical/read-only document corrections go through `docs/requests.md` as instructed by DBVC. Do not copy this entire package into multiple DBVC docs folders.

Changes to routes, commands, hooks, options, tables, scheduled hooks, addon gates or safety contracts require `docs/agents/MAINTENANCE.md`: inspect discovery, curate ownership/evidence, rebuild generated indexes, run strict checks. Never hand-edit all generated indexes. Keep old verification evidence scoped; only mark live verification for the exact same-checkout bounded capability exercised.

## Suggested repository coordination

Use a task branch in each repository with one written compatibility note. Update the observation schema only with the matching adapter fixtures. Keep old hub/site combinations reporting-only or explicitly incompatible according to negotiation; absence of an apply capability is normal. No released hub version should force every client plugin to update simultaneously merely to retain visibility.

## Session finish record

Use `tracking/SESSION-HANDOFF.md`. It is working documentation, not an instruction to modify a Codex/Claude skill or global agent configuration. Do not overwrite existing agent rules or install global packages as part of this scaffold.
