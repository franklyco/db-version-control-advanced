# Draft contracts

Observation schema covers only the first three domains. It intentionally has no sender-selected agency/client/recipient list, raw values or credentials. Hub derives membership from the authenticated enrolled identity. `object.instance_uid` uses the existing entity UID for service posts, scoped to the enrolled client; Bricks uses the sidecar mapping described in the identity document.

`projection.hash` is a semantic digest under the named domain/profile; `complete=false` is never evidence of a clean state. A deletion is `exists=false` with the profile's canonical missing-state digest. It is a report, not a delete instruction. `sequence` is monotonic within one enrolled environment/epoch; a sequence gap or restored epoch needs reconciliation. Before/after rich snapshots and destination storage fingerprints belong to separately scoped APIs/storage, not ordinary metadata events.

All fixtures are synthetic. The hash in example events is syntactically valid placeholder data, not a measured live-site digest. JSON Schema validation alone proves shape, not trusted enrollment, event ordering, atomic receipt persistence, or safe execution. The production signature/version contract remains to be finalized in M0.

`scripts/spec_model.py` is an executable policy illustration with in-memory state; it is not a server or durable queue and does not implement signature verification, gap recovery, an inbox or WordPress integration. It validates only the fields it uses; use the complete schema with a standards-compliant validator in production contract tests.
