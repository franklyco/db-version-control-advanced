# Proposed DBVC integration scaffold

`DomainObserver.php` is an inert proposed interface, not an existing DBVC API. Do not copy/bootstrap it until M0 confirms namespace, loading, PHP support and error/DTO conventions. There is no apply method because the observation pilot does not need one.

Planned module: optional connected-environments gate → Connected runtime → domain observers → dirty-object store/reconciler → outbox/transport. Bricks observer reads allowlisted supported objects; generic post observer resolves existing UIDs. Visual Editor adapter can attach context after successful complete mutations but must not be required.

Candidate service filenames to create only as needed: `ConnectionModule.php`, `EnrollmentStore.php`, `DirtyObjectStore.php`, `SnapshotService.php`, `OutboxStore.php`, `ReportWorker.php`, `HubClient.php`, `BricksDomainObserver.php`, `PostDomainObserver.php`. All are proposed. Reuse existing logger/migration/service patterns instead of blindly generating these names.

Do not turn `dbvc_after_option_update` into the sole reporter hook or make reporting depend on legacy auto-export. Avoid two parallel capture systems: route overlapping WordPress/DBVC/Visual Editor hints through one deduplicated local dirty-object service. Add new completed-change hook only if useful, with explicit payload/timing tests and manifest ownership.

Defaults: module off; no enrollment; no background requests; no content writers. Enabling reporting changes local metadata/outbox and hub metadata, not site content. Future execution must be a separately advertised/authorized capability.
