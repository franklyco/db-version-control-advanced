# Scaffold boundary

The hub PHP shell is real minimal bootstrap code, pending local PHP/WordPress validation. The DBVC interface is a proposal and remains unregistered. No transport, queues, tables, compare UI, credential store, release engine or automatic linkage is implemented here.

Use this scaffold after local reconciliation. The executable specification under `scripts/` is a disposable design aid; production comparison/routing should be implemented in PHP through the owners described in the docs, not by invoking the Python demo from WordPress.
