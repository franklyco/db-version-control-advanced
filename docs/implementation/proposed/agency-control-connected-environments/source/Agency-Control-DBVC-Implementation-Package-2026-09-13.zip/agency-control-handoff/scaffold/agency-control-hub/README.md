# Agency Control development shell

This is a minimal WordPress plugin bootstrap and administrator-only Tools page. It installs no tables, stores no credentials, registers no REST endpoints, starts no cron jobs and makes no network requests. Its page truthfully states no sites are connected.

After local PHP lint and instruction review, copy this directory into a new `agency-control-hub` repository. Install only on the designated disposable hub instance for activation QA. Do not upload the entire handoff ZIP as a WordPress plugin. No installer in this package modifies an existing repository or WordPress site.

Add M2 Registry/Events/Routing services as the observation contract is proven. Keep the hub independent of DBVC PHP classes; communicate through the versioned protocol. If DBVC is also installed on the hub as a studio source, it remains a separate site participant with explicit identity.
