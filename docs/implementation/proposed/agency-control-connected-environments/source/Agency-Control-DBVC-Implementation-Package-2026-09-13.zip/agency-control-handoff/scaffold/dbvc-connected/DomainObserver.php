<?php
namespace Dbvc\Connected\Contracts;

/**
 * Proposed read-only seam. Not registered or loaded into DBVC by this package.
 * Concrete DTO/error signatures must be reconciled with local repository style.
 */
interface DomainObserver
{
    /** Supported domain/profile versions and inventory coverage; never imply apply support. */
    public function capabilities();

    /** Bounded inventory; no UID backfill, directory creation, export or network calls. */
    public function inventory(array $query);

    /** Return persisted canonical projection, version and completeness or explicit unavailable state. */
    public function snapshot(array $objectIdentity);
}
