<?php
/**
 * Plugin Name: Agency Control Hub — Development Shell
 * Description: Planning scaffold with an administrator status page only. No connected-site functionality is implemented.
 * Version: 0.0.1
 * Author: Flourish Web Co
 * Text Domain: agency-control-hub
 */
if (!defined('ABSPATH')) {
    exit;
}
require_once __DIR__ . '/src/Plugin.php';
\Flourish\AgencyControl\Plugin::register();
