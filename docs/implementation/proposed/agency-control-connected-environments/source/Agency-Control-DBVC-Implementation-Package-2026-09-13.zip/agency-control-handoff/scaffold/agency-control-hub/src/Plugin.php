<?php
namespace Flourish\AgencyControl;

final class Plugin
{
    public static function register()
    {
        add_action('admin_menu', [self::class, 'addMenu']);
    }

    public static function addMenu()
    {
        add_management_page(
            __('Agency Control', 'agency-control-hub'),
            __('Agency Control', 'agency-control-hub'),
            'manage_options',
            'agency-control-hub',
            [self::class, 'render']
        );
    }

    public static function render()
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You cannot access this page.', 'agency-control-hub'));
        }
        echo '<div class="wrap"><h1>' . esc_html__('Agency Control', 'agency-control-hub') . '</h1>';
        echo '<p>' . esc_html__('Development shell. No websites are connected.', 'agency-control-hub') . '</p>';
        echo '<p>' . esc_html__('Next milestone: observe framework and client content changes in a disposable test ecosystem.', 'agency-control-hub') . '</p>';
        echo '</div>';
    }
}
