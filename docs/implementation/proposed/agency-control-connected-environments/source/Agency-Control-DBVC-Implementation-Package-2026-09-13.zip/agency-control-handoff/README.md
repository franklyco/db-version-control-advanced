# Agency Control + DBVC

Start with [START-HERE.md](START-HERE.md).

This is a source-grounded implementation handoff, draft contracts, minimal development scaffold and offline policy specification. It is not a completed connected-environment plugin.
