# Script boundaries

`inspect_dbvc.py` reads a selected DBVC checkout and writes a new report outside it. It reads a bounded set of files, uses Git without optional locks, and invokes no WordPress/network/installer command. It rejects an existing output path. Run it with an actual checkout path, not the path of this handoff package.

`demo.py` and `spec_model.py` operate solely on synthetic JSON and in-memory values. `Ledger` demonstrates deduplication outcomes but is not durable, atomic or a complete gap-recovery design. Production must not invoke this Python model as its implementation.

Run the bundled unit tests from the package root. Python 3.9+ is a reasonable local tool target; only the standard library is used. No virtual environment or third-party install is required for the examples. Full JSON Schema checking needs a standards-compliant validator and is separately documented in the package evidence.
