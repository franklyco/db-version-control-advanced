#!/usr/bin/env python3
from pathlib import Path
import json
from spec_model import route, compare, framework_status

root=Path(__file__).resolve().parents[1]
registry=json.loads((root/'contracts/examples/registry.json').read_text())
for name in ('class-observation','service-observation'):
    event=json.loads((root/f'contracts/examples/{name}.json').read_text())
    print(json.dumps({'example':name,**route(event,'a-prod',registry)},indent=2))
print(json.dumps({'three_way':compare('base','staging-edit','prod-edit'),
                  'framework':framework_status('base','base','1.0','1.1')},indent=2))
