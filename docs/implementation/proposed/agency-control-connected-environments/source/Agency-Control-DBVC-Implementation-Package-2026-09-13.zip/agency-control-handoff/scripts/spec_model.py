"""Offline executable examples. Not production routing, auth, or sync code."""
import hashlib
import json

def fingerprint(value=None, *, exists=True):
    # Illustration only: domain-specific PHP normalization/number rules still need fixtures.
    projection = {'exists': exists}
    if exists:
        projection['value'] = value
    raw = json.dumps(projection, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(raw.encode()).hexdigest()

def compare(base, source, target, *, complete=True, profiles=('v1','v1','v1')):
    if not complete or len(set(profiles)) != 1 or source is None or target is None:
        return 'unknown'
    if base is None:
        return 'baseline_required'
    if source == target:
        return 'synchronized' if source == base else 'converged'
    if target == base:
        return 'outgoing'
    if source == base:
        return 'incoming'
    return 'conflict'

def framework_status(actual, adopted_hash, adopted_version, desired_version, override_hash=None):
    if actual is None or adopted_hash is None:
        return {'drift':'unknown','version':'unknown'}
    if override_hash is not None:
        drift = 'approved_override' if actual == override_hash else 'override_changed'
    else:
        drift = 'clean' if actual == adopted_hash else 'local_drift'
    return {'drift':drift,'version':'current' if adopted_version == desired_version else 'behind_version'}

def route(event, principal_environment, registry):
    """principal_environment is trusted test input, never supplied as event authority."""
    envs = registry['environments']
    source = envs.get(principal_environment)
    if not source or not source['enabled'] or event['environment_id'] != principal_environment:
        raise ValueError('enrollment_mismatch')
    if any(k in event for k in ('agency_id','client_id','recipients','audience')):
        raise ValueError('sender_authority_forbidden')
    obj = event['object']
    targets = set()
    for sub in registry['client_subscriptions']:
        target = envs.get(sub['target'])
        if (sub['source'] == principal_environment and target and target['enabled']
            and target['agency'] == source['agency'] and target['client'] == source['client']
            and sub['target'] != principal_environment and obj['domain'] in sub['domains']):
            # Offline != disabled. Delivery stays pending in the proposed real system.
            targets.add(sub['target'])
    framework = sorted({s['definition_uid'] for s in registry['framework_subscriptions']
        if s['agency'] == source['agency'] and s['client'] == source['client']
        and s['domain'] == obj['domain'] and s['instance_uid'] == obj['instance_uid']})
    if event['origin'] in ('apply','rollback'):
        framework = []  # Actual observation still routes; it is not a new promotion proposal.
    return {'client_targets':sorted(targets),'framework_review':framework}

class Ledger:
    """In-memory dedup/sequence example only; lacks production atomic storage/recovery."""
    def __init__(self, environment, epoch):
        self.environment, self.epoch = environment, epoch
        self.events, self.sequences, self.highest = {}, {}, 0

    def accept(self, event):
        if event['environment_id'] != self.environment or event['installation_epoch'] != self.epoch:
            raise ValueError('identity_or_epoch_mismatch')
        seq = event['sequence']
        if type(seq) is not int or seq < 1:
            raise ValueError('sequence_invalid')
        digest = fingerprint(event)
        event_id = event['event_id']
        if event_id in self.events:
            if self.events[event_id] != digest:
                raise ValueError('event_id_reused')
            return 'duplicate'
        if seq in self.sequences:
            raise ValueError('sequence_reused')
        outcome = 'historical' if seq < self.highest else ('gap' if seq > self.highest + 1 else 'accepted')
        self.events[event_id] = digest
        self.sequences[seq] = event_id
        self.highest = max(self.highest, seq)
        return outcome
