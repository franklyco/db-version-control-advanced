import unittest
import json
import sys
from pathlib import Path
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from spec_model import compare, fingerprint, route, framework_status, Ledger

class SpecificationTests(unittest.TestCase):
    def setUp(self):
        self.event=json.loads((ROOT/'contracts/examples/class-observation.json').read_text())
        self.registry=json.loads((ROOT/'contracts/examples/registry.json').read_text())

    def test_three_way_truth_table(self):
        for base,source,target,expected in [
            ('a','a','a','synchronized'),('a','b','a','outgoing'),
            ('a','a','b','incoming'),('a','b','b','converged'),
            ('a','b','c','conflict'),(None,'a','a','baseline_required')]:
            with self.subTest(expected=expected):
                self.assertEqual(compare(base,source,target),expected)

    def test_incomplete_is_unknown(self):
        self.assertEqual(compare('a','a','a',complete=False),'unknown')

    def test_profile_mismatch_is_unknown(self):
        self.assertEqual(compare('a','a','a',profiles=('v1','v2','v1')),'unknown')

    def test_unobserved_state_is_unknown(self):
        self.assertEqual(compare('a',None,'a'),'unknown')

    def test_dictionary_order_not_semantic(self):
        self.assertEqual(fingerprint({'x':1,'y':2}),fingerprint({'y':2,'x':1}))

    def test_array_order_is_semantic(self):
        self.assertNotEqual(fingerprint(['one','two']),fingerprint(['two','one']))

    def test_missing_null_empty_types_distinct(self):
        hashes=[fingerprint(exists=False),fingerprint(None),fingerprint(''),fingerprint([]),fingerprint({})]
        self.assertEqual(len(set(hashes)),5)

    def test_meaningful_time_not_stripped(self):
        self.assertNotEqual(fingerprint({'time':'9am'}),fingerprint({'time':'10am'}))

    def test_framework_change_routes_to_hub_and_own_staging(self):
        self.assertEqual(route(self.event,'a-prod',self.registry),{
            'client_targets':['a-local','a-stage'],'framework_review':['fw-button']})

    def test_service_stays_in_client_ecosystem(self):
        self.event['object']={'domain':'wp.service','instance_uid':'a-service'}
        self.assertEqual(route(self.event,'a-prod',self.registry),{
            'client_targets':['a-local','a-stage'],'framework_review':[]})

    def test_unmanaged_class_not_framework_item(self):
        self.event['object']['instance_uid']='a-custom'
        self.assertEqual(route(self.event,'a-prod',self.registry)['framework_review'],[])

    def test_offline_subscribed_staging_is_retained(self):
        self.assertIn('a-local',route(self.event,'a-prod',self.registry)['client_targets'])

    def test_disabled_staging_is_excluded(self):
        self.registry['environments']['a-stage']['enabled']=False
        self.assertEqual(route(self.event,'a-prod',self.registry)['client_targets'],['a-local'])

    def test_misconfigured_cross_client_subscription_does_not_route(self):
        self.registry['client_subscriptions'].append({'source':'a-prod','target':'b-stage','domains':['bricks.global_class']})
        self.assertNotIn('b-stage',route(self.event,'a-prod',self.registry)['client_targets'])

    def test_spoofed_environment_rejected(self):
        with self.assertRaisesRegex(ValueError,'enrollment_mismatch'):
            route(self.event,'b-prod',self.registry)

    def test_sender_cannot_select_recipients(self):
        self.event['recipients']=['b-stage']
        with self.assertRaisesRegex(ValueError,'sender_authority_forbidden'):
            route(self.event,'a-prod',self.registry)

    def test_apply_observation_is_not_new_framework_proposal(self):
        self.event['origin']='apply'
        result=route(self.event,'a-prod',self.registry)
        self.assertEqual(result['framework_review'],[])
        self.assertEqual(result['client_targets'],['a-local','a-stage'])

    def test_new_framework_version_not_local_drift(self):
        self.assertEqual(framework_status('x','x','1','2'),{'drift':'clean','version':'behind_version'})

    def test_override_remains_intentional_when_version_behind(self):
        self.assertEqual(framework_status('override','base','1','2','override'),{'drift':'approved_override','version':'behind_version'})

    def test_changed_override_is_fresh_drift(self):
        self.assertEqual(framework_status('later','base','1','1','override')['drift'],'override_changed')

    def test_duplicate_event(self):
        ledger=Ledger('a-prod','epoch-a1')
        self.assertEqual(ledger.accept(self.event),'accepted')
        self.assertEqual(ledger.accept(self.event),'duplicate')

    def test_reused_id_with_different_body_rejected(self):
        ledger=Ledger('a-prod','epoch-a1'); ledger.accept(self.event)
        self.event['projection']['hash']='b'*64
        with self.assertRaisesRegex(ValueError,'event_id_reused'): ledger.accept(self.event)

    def test_gap_and_late_event_do_not_move_state_back(self):
        ledger=Ledger('a-prod','epoch-a1')
        later=deepcopy(self.event); later.update(sequence=3,event_id='later')
        self.assertEqual(ledger.accept(later),'gap')
        self.assertEqual(ledger.accept(self.event),'historical')
        self.assertEqual(ledger.highest,3)

    def test_restored_epoch_rejected(self):
        with self.assertRaisesRegex(ValueError,'identity_or_epoch_mismatch'):
            Ledger('a-prod','new-epoch').accept(self.event)

    def test_sequence_collision_rejected(self):
        ledger=Ledger('a-prod','epoch-a1'); ledger.accept(self.event)
        self.event['event_id']='different'
        with self.assertRaisesRegex(ValueError,'sequence_reused'): ledger.accept(self.event)

if __name__=='__main__': unittest.main()
