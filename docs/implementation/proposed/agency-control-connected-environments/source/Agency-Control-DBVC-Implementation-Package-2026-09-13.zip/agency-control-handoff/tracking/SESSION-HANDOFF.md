# Session handoff template

- Date / agent:
- Milestone and bounded claim:
- Repository paths / branches / HEADs / relevant dirty files:
- Active WordPress plugin path and versions (if exercised):
- Existing services adopted; new surfaces:
- Files changed:
- Commands and actual results:
- Fixture IDs / before-after evidence / cleanup:
- Capability records and docs updated:
- Known blockers and untested boundaries:
- Next concrete task:
- Authority boundary for next task (local code, disposable fixtures, production):

Do not include credentials, full client content, private URLs containing tokens, or invented pass results.
