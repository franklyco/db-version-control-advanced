# Initial decisions

Status: architectural recommendations accepted in conversation; implementation remains proposed.

| ID | Decision | Revisit trigger |
|---|---|---|
| D01 | Separate hub, DBVC execution module; no engine fork | A concrete incompatible runtime constraint |
| D02 | Visual Editor optional and retained in DBVC initially | Independent release/installation need outweighs extraction cost |
| D03 | Hub-mediated outbound transport for agency MVP | Proven requirement for direct peer mode |
| D04 | Automatic detection/reporting; reviewed content application | Proven per-domain conflict/recovery and explicit policy authorization |
| D05 | Object ownership/subscription determines audience | No blanket Bricks-domain routing |
| D06 | Separate environment and framework baselines | Any proposed simplification must preserve both semantics |
| D07 | Initial WordPress hub; versioned protocol | Measured host/runtime/scale limits |
| D08 | No AI in deterministic authority/merge decisions | Optional explainability need, with source-bound limits |
| D09 | Local dirty state takes precedence over remote assumptions | Reconcile each implementation session |
