# Agency Control + DBVC: local implementation handoff

Prepared for Rhett Butler / Flourish Web Co, 2026-09-13. Working product name: **Agency Control**. This package is a proposed implementation plan and starter, not a functioning synchronization product.

## The decision

Build a separate agency hub plugin and add an optional connection module to DBVC. Keep execution, content identity, imports, domain adapters, and recovery on each site. Keep Visual Editor optional inside DBVC for now. Do not fork the engines or migrate every existing addon before proving value.

First useful outcome: a live-site edit to a managed Bricks class appears in the agency framework queue and the same client's staging view; a service-post edit appears only in that client's subscribed staging views. Another client receives neither change as an incoming update. No content is automatically applied.

## Start locally

1. Unzip outside your existing DBVC checkout. Open this folder and the actual DBVC checkout together in Codex or Claude Code.
2. Read `docs/01-architecture.md`, then `docs/02-reuse-and-evidence.md`.
3. Run the read-only inventory script against your real checkout:

   ```bash
   python3 scripts/inspect_dbvc.py --repo "/absolute/path/to/db-version-control-main" --output "/absolute/path/to/dbvc-discovery.json"
   ```

   It does not fetch, checkout, stash, install dependencies, invoke WordPress, or change that repository. It records file hashes, branch/HEAD, changed filenames, and bounded hook/signature findings. Review reports before sharing; paths can be identifying. Choose a private output directory.
4. Paste `prompts/01-local-discovery.md` into your local coding agent. That prompt checks local uncommitted work before selecting an implementation base.
5. Once discovery and contracts are reconciled, use `prompts/02-observation-pilot.md`. The existing user request authorizes local planning and scaffolding; prompts do not grant production or remote-write authority.

## What is included

| Item | Purpose |
|---|---|
| `docs/01-architecture.md` | Product boundary, repositories, topology, data ownership |
| `docs/02-reuse-and-evidence.md` | Actual DBVC functions/hooks, reuse decisions, evidence caveats |
| `docs/03-identity-and-drift.md` | Two comparison baselines, object lineage, overrides, cloning |
| `docs/04-capture-and-routing.md` | Change detection, event routing, offline behavior, isolation |
| `docs/05-protocol-and-storage.md` | Draft protocol, authentication, persistence and operation semantics |
| `docs/06-release-and-recovery.md` | Later reviewed application, concurrency and recovery boundaries |
| `docs/07-delivery-plan.md` | Ordered milestones, effort ceilings, exit criteria and deferrals |
| `docs/08-validation-and-local-lab.md` | LocalWP fixtures, meaningful tests and evidence recording |
| `docs/09-agent-workflow.md` | Bounded agent sessions, existing scripts, documentation integration |
| `docs/10-experience.md` | Fleet/client/object views, low-noise queues, example operator flow |
| `contracts/` | Draft event schema and synthetic examples; no credentials/client content |
| `scaffold/agency-control-hub/` | Minimal WordPress admin shell; no connection or content writes |
| `scaffold/dbvc-connected/` | Proposed adapter seam and integration instructions, not installed code |
| `scripts/` and `tests/` | Read-only local inspection and an executable routing/comparison specification |
| `evidence/` | Pinned source references and package validation; live evidence remains unrun |
| `tracking/` | Initial tasks, decisions and session handoff template |

## Known source baseline

Primary review: `franklyco/db-version-control-main`, branch `codex/visual-editor-r5-later-arc`, commit `977888535a306989e48c5a34104fb9d101298cf3`, plugin header 1.9.1. Default `master`: `c88764bdbb21546347e474a912237013bc323b21`. Heads were rechecked September 13.

The September 12 commit explicitly excluded some dirty local Bricks portability work. Local discovery is therefore mandatory before applying this plan. Do not reset to the reviewed SHA or assume it contains all of Rhett's latest changes. The advanced repository's September 11 `addon-enhancements` head was a useful prior comparison, not a reason to switch working repositories.

## Run the offline specification

```bash
python3 -B -m unittest discover -s tests -v
python3 scripts/demo.py
```

These tests prove only the bundled policy examples. They do not prove WordPress behavior, HTTP authorization, database concurrency, Bricks rendering, or recovery. See `evidence/PACKAGE-VALIDATION.md` for actual results and limitations. PHP/WordPress must be checked on the local machine before activating the shell.

## First instruction to the agent

“Read START-HERE.md and prompts/01-local-discovery.md. Reconcile this plan with my current DBVC checkout, including uncommitted work. Produce the evidence/reuse map and choose the smallest observation-only implementation slice. Preserve existing instructions and unrelated work.”
